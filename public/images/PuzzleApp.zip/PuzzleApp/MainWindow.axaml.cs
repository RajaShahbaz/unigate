using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Input;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PuzzleApp;

public partial class MainWindow : Window
{
    // ── Config ───────────────────────────────────────────────────────────────
    const int GridSize   = 3;
    const int PieceSize  = 120;
    const int PieceGap   = 6;
    const int SnapRadius = 55;

    // ── Layout (computed once canvas has real bounds) ─────────────────────────
    double _boardOffsetX;
    double _boardOffsetY;
    double _trayX = 15;
    double _trayY = 35;
    double _trayW = 350;

    // ── Piece model ───────────────────────────────────────────────────────────
    private record PuzzlePiece(Image Image, int Index)
    {
        public bool Snapped { get; set; } = false;
    }

    private readonly List<PuzzlePiece> _pieces = new();
    private readonly Random            _rng    = new();

    // ── Drag state ────────────────────────────────────────────────────────────
    private PuzzlePiece? _dragged;
    private Point        _dragOffset;

    // ── Win state ─────────────────────────────────────────────────────────────
    private DateTime _startTime;
    private Border?  _winOverlay;
    private bool     _usedSolve;

    // ── Constructor ───────────────────────────────────────────────────────────
    public MainWindow()
    {
        InitializeComponent();

        // Wire events once; LoadPuzzle can be called repeatedly for shuffle
        GameCanvas.PointerPressed  += OnPointerPressed;
        GameCanvas.PointerMoved    += OnPointerMoved;
        GameCanvas.PointerReleased += OnPointerReleased;

        Opened += (_, _) => LoadPuzzle();
    }

    // ── Load / Shuffle ────────────────────────────────────────────────────────
    void LoadPuzzle()
    {
        _dragged = null;
        _pieces.Clear();
        GameCanvas.Children.Clear();
        _winOverlay = null;   // cleared with Children above
        _startTime  = DateTime.Now;
        _usedSolve  = false;

        // Compute layout now that canvas has real bounds
        double cw = GameCanvas.Bounds.Width;
        double ch = GameCanvas.Bounds.Height;

        double gridW = GridSize * PieceSize + (GridSize - 1) * PieceGap;
        double gridH = GridSize * PieceSize + (GridSize - 1) * PieceGap;

        // Right half: board
        _boardOffsetX = cw / 2 + (cw / 2 - gridW) / 2;
        _boardOffsetY = (ch - gridH) / 2;

        // Left half: tray
        _trayX = 10;
        _trayY = 10;
        _trayW = cw / 2 - 20;

        // Draw static background panels and snap grid (z=0)
        DrawRegions(cw, ch, gridW, gridH);
        DrawSnapGrid();

        // Split image into pieces
        var bitmap      = new Bitmap("Assets/puzzle.jpg");
        var splitPieces = ImageSplitter.Split(bitmap, GridSize, GridSize);

        for (int i = 0; i < splitPieces.Count; i++)
        {
            var img = new Image
            {
                Source                = splitPieces[i],
                Width                 = PieceSize,
                Height                = PieceSize,
                Stretch               = Stretch.Fill,
                Cursor                = new Cursor(StandardCursorType.Hand),
                RenderTransformOrigin = RelativePoint.Center,
                ZIndex                = 10,
            };
            _pieces.Add(new PuzzlePiece(img, i));
        }

        PlaceOnTray();
        UpdateStatus();
    }

    // ── Draw background regions ───────────────────────────────────────────────
    void DrawRegions(double cw, double ch, double gridW, double gridH)
    {
        // Tray panel
        var trayBg = new Border
        {
            Width           = cw / 2 - 20,
            Height          = ch - 20,
            Background      = new SolidColorBrush(Color.Parse("#16213e")),
            CornerRadius    = new CornerRadius(12),
            ZIndex          = 0,
        };
        Canvas.SetLeft(trayBg, 10);
        Canvas.SetTop(trayBg,  10);
        GameCanvas.Children.Add(trayBg);

        var trayLabel = new TextBlock
        {
            Text       = "PIECES",
            Foreground = new SolidColorBrush(Color.Parse("#a0a0c0")),
            FontSize   = 11,
            ZIndex     = 1,
        };
        Canvas.SetLeft(trayLabel, cw / 4 - 20);
        Canvas.SetTop(trayLabel,  20);
        GameCanvas.Children.Add(trayLabel);

        // Board panel
        var boardBg = new Border
        {
            Width        = cw / 2 - 20,
            Height       = ch - 20,
            Background   = new SolidColorBrush(Color.Parse("#0d0d1a")),
            CornerRadius = new CornerRadius(12),
            ZIndex       = 0,
        };
        Canvas.SetLeft(boardBg, cw / 2 + 10);
        Canvas.SetTop(boardBg,  10);
        GameCanvas.Children.Add(boardBg);

        var boardLabel = new TextBlock
        {
            Text       = "PUZZLE BOARD",
            Foreground = new SolidColorBrush(Color.Parse("#a0a0c0")),
            FontSize   = 11,
            ZIndex     = 1,
        };
        Canvas.SetLeft(boardLabel, cw * 3 / 4 - 35);
        Canvas.SetTop(boardLabel,  20);
        GameCanvas.Children.Add(boardLabel);
    }

    // ── Draw ghost snap-grid slots ────────────────────────────────────────────
    void DrawSnapGrid()
    {
        for (int row = 0; row < GridSize; row++)
        for (int col = 0; col < GridSize; col++)
        {
            var slot = new Border
            {
                Width           = PieceSize,
                Height          = PieceSize,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(90, 120, 120, 220)),
                BorderThickness = new Thickness(1.5),
                CornerRadius    = new CornerRadius(4),
                Background      = new SolidColorBrush(Color.FromArgb(30, 80, 80, 180)),
                ZIndex          = 1,
            };
            Canvas.SetLeft(slot, _boardOffsetX + col * (PieceSize + PieceGap));
            Canvas.SetTop(slot,  _boardOffsetY + row * (PieceSize + PieceGap));
            GameCanvas.Children.Add(slot);
        }
    }

    // ── Place all un-snapped pieces randomly in the tray ─────────────────────
    void PlaceOnTray()
    {
        var shuffled = _pieces.OrderBy(_ => _rng.Next()).ToList();

        int cols = Math.Max(1, (int)((_trayW - 20) / (PieceSize + 10)));
        int col  = 0, row = 0;

        foreach (var piece in shuffled)
        {
            double x = _trayX + 20 + col * (PieceSize + 10);
            double y = _trayY + 40 + row * (PieceSize + 10);

            Canvas.SetLeft(piece.Image, x);
            Canvas.SetTop(piece.Image,  y);
            piece.Image.ZIndex = 10;

            GameCanvas.Children.Add(piece.Image);

            col++;
            if (col >= cols) { col = 0; row++; }
        }
    }

    // ── Pointer: Pressed ──────────────────────────────────────────────────────
    void OnPointerPressed(object? sender, PointerPressedEventArgs e)
    {
        if (_dragged != null) return;
        var pos = e.GetPosition(GameCanvas);

        var piece = HitTest(pos);
        if (piece == null || piece.Snapped) return;

        _dragged    = piece;
        _dragOffset = new Point(
            pos.X - Canvas.GetLeft(piece.Image),
            pos.Y - Canvas.GetTop(piece.Image));

        // Bring to front visually
        piece.Image.ZIndex = 1000;

        // Slight scale-up feedback
        piece.Image.RenderTransform = new ScaleTransform(1.06, 1.06);

        // Capture: guarantees PointerMoved fires even if mouse leaves the canvas
        e.Pointer.Capture(GameCanvas);
        e.Handled = true;
    }

    // ── Pointer: Moved ────────────────────────────────────────────────────────
    void OnPointerMoved(object? sender, PointerEventArgs e)
    {
        if (_dragged == null) return;
        var pos = e.GetPosition(GameCanvas);

        Canvas.SetLeft(_dragged.Image, pos.X - _dragOffset.X);
        Canvas.SetTop(_dragged.Image,  pos.Y - _dragOffset.Y);
        e.Handled = true;
    }

    // ── Pointer: Released ─────────────────────────────────────────────────────
    void OnPointerReleased(object? sender, PointerReleasedEventArgs e)
    {
        if (_dragged == null) return;
        e.Pointer.Capture(null);

        double x = Canvas.GetLeft(_dragged.Image);
        double y = Canvas.GetTop(_dragged.Image);

        bool snapped = TrySnap(_dragged, x, y);

        _dragged.Image.RenderTransform = null;
        _dragged.Image.ZIndex          = snapped ? 5 : 10;
        _dragged = null;

        UpdateStatus();
        CheckWin();
    }

    // ── Snap logic ────────────────────────────────────────────────────────────
    bool TrySnap(PuzzlePiece piece, double x, double y)
    {
        int    col   = piece.Index % GridSize;
        int    row   = piece.Index / GridSize;
        double snapX = _boardOffsetX + col * (PieceSize + PieceGap);
        double snapY = _boardOffsetY + row * (PieceSize + PieceGap);

        double dist = Math.Sqrt(
            Math.Pow(x - snapX, 2) +
            Math.Pow(y - snapY, 2));

        if (dist > SnapRadius) return false;

        Canvas.SetLeft(piece.Image, snapX);
        Canvas.SetTop(piece.Image,  snapY);
        piece.Image.ZIndex = 5;
        piece.Snapped      = true;
        return true;
    }

    // ── Hit-test: topmost un-snapped piece under cursor ───────────────────────
    PuzzlePiece? HitTest(Point pos)
    {
        PuzzlePiece? best  = null;
        int          bestZ = -1;

        foreach (var piece in _pieces)
        {
            double left = Canvas.GetLeft(piece.Image);
            double top  = Canvas.GetTop(piece.Image);
            var    rect = new Rect(left, top, PieceSize, PieceSize);

            if (!rect.Contains(pos)) continue;

            if (piece.Image.ZIndex > bestZ)
            {
                bestZ = piece.Image.ZIndex;
                best  = piece;
            }
        }
        return best;
    }

    // ── Status bar ────────────────────────────────────────────────────────────
    void UpdateStatus()
    {
        int snapped = _pieces.Count(p => p.Snapped);
        StatusText.Text = snapped == _pieces.Count
            ? "🎉 Puzzle solved!"
            : $"{snapped}/{_pieces.Count} pieces placed";
    }

    void CheckWin()
    {
        if (!_pieces.All(p => p.Snapped)) return;
        ShowWinOverlay();
    }

    void ShowWinOverlay()
    {
        var elapsed = DateTime.Now - _startTime;
        string time = elapsed.TotalSeconds < 60
            ? $"{(int)elapsed.TotalSeconds} seconds"
            : $"{(int)elapsed.TotalMinutes}m {elapsed.Seconds}s";

        bool demo = _usedSolve;

        StatusText.Text = demo ? "🔍 Demo mode" : "🎉 Puzzle complete!";

        double cw = GameCanvas.Bounds.Width;
        double ch = GameCanvas.Bounds.Height;

        if (demo)
        {
            // ── Demo: compact bottom banner (puzzle stays fully visible) ──────
            const double bannerH = 70;

            _winOverlay = new Border
            {
                Width           = cw,
                Height          = bannerH,
                Background      = new SolidColorBrush(Color.FromArgb(230, 15, 52, 96)),
                BorderBrush     = new SolidColorBrush(Color.Parse("#e94560")),
                BorderThickness = new Thickness(0, 2, 0, 0),
                ZIndex          = 5000,
            };

            var row = new StackPanel
            {
                Orientation         = Avalonia.Layout.Orientation.Horizontal,
                Spacing             = 20,
                HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
                VerticalAlignment   = Avalonia.Layout.VerticalAlignment.Center,
            };

            row.Children.Add(new TextBlock
            {
                Text              = "🔍  This is a demo — the puzzle is solved automatically.",
                FontSize          = 14,
                Foreground        = new SolidColorBrush(Color.Parse("#c0c0e0")),
                VerticalAlignment = Avalonia.Layout.VerticalAlignment.Center,
            });

            var tryBtn = new Button
            {
                Content      = "🎮  Try It Yourself",
                Padding      = new Thickness(18, 8),
                FontSize     = 13,
                FontWeight   = FontWeight.SemiBold,
                Foreground   = Brushes.White,
                Background   = new SolidColorBrush(Color.Parse("#e94560")),
                CornerRadius = new CornerRadius(8),
                Cursor       = new Cursor(StandardCursorType.Hand),
                VerticalAlignment = Avalonia.Layout.VerticalAlignment.Center,
            };
            tryBtn.Click += (_, _) => LoadPuzzle();
            row.Children.Add(tryBtn);

            // Wrap in a centring Grid
            var grid = new Grid();
            grid.Children.Add(row);
            _winOverlay.Child = grid;

            Canvas.SetLeft(_winOverlay, 0);
            Canvas.SetTop(_winOverlay, ch - bannerH);
            GameCanvas.Children.Add(_winOverlay);
        }
        else
        {
            // ── Real win: full-screen congratulations overlay ─────────────────
            _winOverlay = new Border
            {
                Width      = cw,
                Height     = ch,
                Background = new SolidColorBrush(Color.FromArgb(210, 10, 10, 30)),
                ZIndex     = 5000,
            };

            var card = new Border
            {
                Background      = new SolidColorBrush(Color.Parse("#16213e")),
                CornerRadius    = new CornerRadius(20),
                BorderBrush     = new SolidColorBrush(Color.Parse("#e94560")),
                BorderThickness = new Thickness(2),
                Padding         = new Thickness(50, 40),
                HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
                VerticalAlignment   = Avalonia.Layout.VerticalAlignment.Center,
            };

            var stack = new StackPanel
            {
                Spacing = 16,
                HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
            };

            stack.Children.Add(new TextBlock
            {
                Text                = "🎉 🧩 🎉",
                FontSize            = 48,
                HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
            });
            stack.Children.Add(new TextBlock
            {
                Text                = "Congratulations!",
                FontSize            = 32,
                FontWeight          = FontWeight.Bold,
                Foreground          = new SolidColorBrush(Color.Parse("#e94560")),
                HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
            });
            stack.Children.Add(new TextBlock
            {
                Text                = "You solved the puzzle!",
                FontSize            = 18,
                Foreground          = new SolidColorBrush(Color.Parse("#c0c0e0")),
                HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
            });
            stack.Children.Add(new TextBlock
            {
                Text                = $"⏱ Time: {time}",
                FontSize            = 16,
                Foreground          = new SolidColorBrush(Color.Parse("#a0a0c0")),
                HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
            });

            var playAgain = new Button
            {
                Content      = "🔀  Play Again",
                Padding      = new Thickness(30, 12),
                FontSize     = 16,
                FontWeight   = FontWeight.SemiBold,
                Foreground   = Brushes.White,
                Background   = new SolidColorBrush(Color.Parse("#e94560")),
                CornerRadius = new CornerRadius(10),
                Cursor       = new Cursor(StandardCursorType.Hand),
                HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
            };
            playAgain.Click += (_, _) => LoadPuzzle();
            stack.Children.Add(playAgain);

            card.Child = stack;

            var centreGrid = new Grid();
            centreGrid.Children.Add(card);
            _winOverlay.Child = centreGrid;

            Canvas.SetLeft(_winOverlay, 0);
            Canvas.SetTop(_winOverlay,  0);
            GameCanvas.Children.Add(_winOverlay);
        }
    }

    // ── Buttons ───────────────────────────────────────────────────────────────
    void OnShuffleClicked(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
        => LoadPuzzle();

    void OnSolveClicked(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        _usedSolve = true;
        foreach (var piece in _pieces)
        {
            piece.Snapped      = true;
            int col            = piece.Index % GridSize;
            int row            = piece.Index / GridSize;
            Canvas.SetLeft(piece.Image, _boardOffsetX + col * (PieceSize + PieceGap));
            Canvas.SetTop(piece.Image,  _boardOffsetY + row * (PieceSize + PieceGap));
            piece.Image.ZIndex = 5;
            piece.Image.RenderTransform = null;
        }
        UpdateStatus();
        CheckWin();
    }
}