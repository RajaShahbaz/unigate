using Avalonia.Media.Imaging;
using Avalonia;
using System.Collections.Generic;

namespace PuzzleApp;

public static class ImageSplitter
{
    public static List<CroppedBitmap> Split(Bitmap source, int rows, int cols)
    {
        var pieces = new List<CroppedBitmap>();

        int pieceWidth = source.PixelSize.Width / cols;
        int pieceHeight = source.PixelSize.Height / rows;

        for (int y = 0; y < rows; y++)
        {
            for (int x = 0; x < cols; x++)
            {
                var rect = new PixelRect(
                    x * pieceWidth,
                    y * pieceHeight,
                    pieceWidth,
                    pieceHeight
                );

                pieces.Add(new CroppedBitmap(source, rect));
            }
        }

        return pieces;
    }
}